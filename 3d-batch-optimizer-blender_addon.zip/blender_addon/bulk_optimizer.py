#!/usr/bin/env python3
"""
Backend optimization module for the Blender addon
Contains the core processing logic adapted from the standalone script
"""

import bpy
import bmesh
import os
import sys
import traceback
from pathlib import Path
from mathutils import Vector
import tempfile
import shutil

def log(message, level="INFO", report_func=None):
    """Print formatted log message and report to Blender UI if available."""
    print(f"[{level}] {message}")
    if report_func:
        if level == "ERROR":
            report_func({'ERROR'}, message)
        elif level == "WARNING":
            report_func({'WARNING'}, message)
        else:
            report_func({'INFO'}, message)

def clear_scene(verbose=True, report_func=None):
    """Clear all objects, materials, and images from the current scene."""
    try:
        # Clear all mesh objects
        bpy.ops.object.select_all(action='SELECT')
        bpy.ops.object.delete(use_global=False)
        
        # Clear orphaned data
        for block in bpy.data.meshes:
            bpy.data.meshes.remove(block)
        for block in bpy.data.materials:
            bpy.data.materials.remove(block)
        for block in bpy.data.images:
            bpy.data.images.remove(block)
        for block in bpy.data.textures:
            bpy.data.textures.remove(block)
        for block in bpy.data.node_groups:
            bpy.data.node_groups.remove(block)
            
        # Clear collections
        for collection in bpy.data.collections:
            bpy.data.collections.remove(collection)
            
        if verbose:
            log("Scene cleared successfully", report_func=report_func)
            
    except Exception as e:
        log(f"Warning: Error clearing scene: {e}", "WARNING", report_func)

def get_file_type(filepath):
    """Determine file type based on extension."""
    ext = filepath.suffix.lower()
    if ext in ['.glb', '.gltf']:
        return 'gltf'
    elif ext == '.vrm':
        return 'vrm'
    else:
        return 'unknown'

def import_file(input_path, verbose=True, report_func=None):
    """Import file based on its type."""
    file_type = get_file_type(input_path)
    
    if file_type == 'gltf':
        try:
            bpy.ops.import_scene.gltf(filepath=str(input_path))
            if verbose:
                log(f"Imported GLTF/GLB file: {input_path.name}", report_func=report_func)
            return True
        except Exception as e:
            log(f"Error importing GLTF/GLB file '{input_path}': {e}", "ERROR", report_func)
            # Try fallback for animation issues
            if "bone" in str(e).lower() or "animation" in str(e).lower():
                log(f"Animation/bone error - attempting to continue without animations", "WARNING", report_func)
                try:
                    bpy.ops.import_scene.gltf(filepath=str(input_path), import_pack_images=True)
                    if verbose:
                        log(f"Imported GLTF/GLB file without animations: {input_path.name}", report_func=report_func)
                    return True
                except Exception as e2:
                    log(f"Failed to import even without animations: {e2}", "ERROR", report_func)
                    return False
            else:
                return False
    
    elif file_type == 'vrm':
        try:
            bpy.ops.import_scene.vrm(filepath=str(input_path))
            if verbose:
                log(f"Imported VRM file: {input_path.name}", report_func=report_func)
            return True
        except Exception as e:
            log(f"Error importing VRM file '{input_path}': {e}", "ERROR", report_func)
            return False
    
    else:
        log(f"Unsupported file type: {input_path.suffix}", "ERROR", report_func)
        return False

def export_file(output_path, file_type, verbose=True, report_func=None):
    """Export file based on desired output type."""
    try:
        # Ensure output directory exists
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        if file_type == 'vrm':
            # Export as VRM
            try:
                bpy.ops.export_scene.vrm(filepath=str(output_path))
            except TypeError as e:
                # Fallback for different VRM addon versions
                if verbose:
                    log(f"Using fallback VRM export parameters due to: {e}", report_func=report_func)
                bpy.ops.export_scene.vrm(filepath=str(output_path))
        
        elif file_type == 'gltf':
            # Export as GLTF (separate files) for better compatibility
            try:
                bpy.ops.export_scene.gltf(
                    filepath=str(output_path),
                    export_format='GLTF_SEPARATE',
                    export_materials='EXPORT',
                    export_colors=True,
                    export_cameras=False,
                    export_lights=False,
                    export_animations=True,
                    export_yup=True,
                    export_apply=False,
                    export_texcoords=True,
                    export_normals=True,
                    export_draco_mesh_compression_enable=False,
                    export_tangents=False,
                    use_selection=False,
                    use_visible=False,
                    use_renderable=False,
                    use_active_collection=False,
                    use_active_scene=False
                )
            except TypeError as e:
                # Fallback for older Blender versions
                if verbose:
                    log(f"Using fallback GLTF export parameters due to: {e}", report_func=report_func)
                bpy.ops.export_scene.gltf(
                    filepath=str(output_path),
                    export_format='GLTF_SEPARATE'
                )
        
        else:
            # Export as GLB (binary format)
            try:
                bpy.ops.export_scene.gltf(
                    filepath=str(output_path),
                    export_format='GLB',
                    export_materials='EXPORT',
                    export_colors=True,
                    export_cameras=False,
                    export_lights=False,
                    export_animations=True,
                    export_yup=True,
                    export_apply=False,
                    export_texcoords=True,
                    export_normals=True,
                    export_draco_mesh_compression_enable=False,
                    export_tangents=False,
                    use_selection=False,
                    use_visible=False,
                    use_renderable=False,
                    use_active_collection=False,
                    use_active_scene=False
                )
            except TypeError as e:
                # Fallback for older Blender versions with minimal parameters
                if verbose:
                    log(f"Using fallback GLB export parameters due to: {e}", report_func=report_func)
                bpy.ops.export_scene.gltf(
                    filepath=str(output_path),
                    export_format='GLB'
                )
        
        return True
        
    except Exception as e:
        log(f"Error exporting file '{output_path}': {e}", "ERROR", report_func)
        return False

def has_alpha_channel(image):
    """Check if image actually uses alpha channel (has transparency)."""
    try:
        if not image or not image.pixels:
            return False
        
        # Check if image has alpha channel data
        if len(image.pixels) % 4 != 0:
            return False  # No alpha channel in pixel data
        
        # Sample alpha values to see if any are not 1.0 (fully opaque)
        pixels = image.pixels[:]
        alpha_values = pixels[3::4]  # Every 4th value is alpha
        
        # If any alpha value is not 1.0, we need transparency
        for alpha in alpha_values:
            if alpha < 0.99:  # Small tolerance for floating point
                return True
        
        return False
    except Exception as e:
        # If we can't determine, assume it might need alpha
        return True

def get_texture_format(image_name, image=None, texture_format='AUTO', aggressive_jpeg=True):
    """Determine optimal texture format based on image type and actual usage."""
    if texture_format == 'PNG':
        return 'PNG'
    elif texture_format == 'JPEG':
        return 'JPEG'
    else:  # AUTO - smart format selection
        name_lower = image_name.lower()
        
        # Always use PNG for normal maps, roughness, metallic (they need precision)
        if any(keyword in name_lower for keyword in ['normal', 'nrm', 'bump', 'roughness', 'metallic']):
            return 'PNG'
        
        # If aggressive JPEG conversion is enabled, check for actual alpha usage
        if aggressive_jpeg:
            # Only keep PNG if image actually uses alpha channel
            if image and has_alpha_channel(image):
                return 'PNG'
            else:
                return 'JPEG'
        else:
            # Conservative approach - check name patterns
            if any(keyword in name_lower for keyword in ['alpha', 'opacity', 'mask']):
                return 'PNG'
        
        # For everything else (diffuse, color, etc.), use JPEG for better compression
        return 'JPEG'

def clean_material_properties(material, remove_specular=True, verbose=True, report_func=None):
    """Remove specular tint and reduce specular to 0 for better compression."""
    if not remove_specular:
        return
        
    try:
        if not material.use_nodes:
            # For materials without nodes, set basic specular properties
            if hasattr(material, 'specular_intensity'):
                material.specular_intensity = 0.0
            if hasattr(material, 'specular_color'):
                material.specular_color = (0.0, 0.0, 0.0)
            if verbose:
                log(f"Set specular properties to 0 on non-node material: {material.name}", report_func=report_func)
            return
        
        nodes_to_remove = []
        
        links_to_remove = []
        
        for node in material.node_tree.nodes:
            # Remove specular tint texture nodes
            if node.type == 'TEX_IMAGE' and node.image:
                image_name_lower = node.image.name.lower()
                node_name_lower = node.name.lower()
                
                # Check both image name and node name for specular tint
                if any(keyword in image_name_lower for keyword in ['specular_tint', 'spectint', 'spec_tint', 'specular tint']) or \
                   any(keyword in node_name_lower for keyword in ['specular_tint', 'spectint', 'spec_tint', 'specular tint']):
                    if verbose:
                        log(f"Removing specular tint texture: {node.image.name} (node: {node.name})", report_func=report_func)
                    # Disconnect all links from this node
                    for output in node.outputs:
                        for link in output.links:
                            links_to_remove.append(link)
                    nodes_to_remove.append(node)
            
            # Set specular values to 0 on principled BSDF
            elif node.type == 'BSDF_PRINCIPLED':
                # Handle different input names for specular
                specular_inputs = []
                
                # Check for various specular input names
                for input_name in ['Specular', 'Specular IOR Level', 'Specular Tint']:
                    if input_name in node.inputs:
                        specular_inputs.append(node.inputs[input_name])
                
                for specular_input in specular_inputs:
                    try:
                        # Disconnect any links to specular input
                        for link in specular_input.links:
                            links_to_remove.append(link)
                        
                        # Set specular to 0
                        if specular_input.name == 'Specular Tint':
                            # Specular Tint can be float or color - check the socket type
                            if hasattr(specular_input, 'default_value'):
                                current_val = specular_input.default_value
                                if isinstance(current_val, (int, float)):
                                    specular_input.default_value = 1.0  # White for float
                                else:
                                    specular_input.default_value = (1.0, 1.0, 1.0, 1.0)  # White for color
                        else:
                            # Regular specular inputs should be 0
                            if hasattr(specular_input, 'default_value'):
                                if isinstance(specular_input.default_value, (int, float)):
                                    specular_input.default_value = 0.0
                                else:
                                    specular_input.default_value = (0.0, 0.0, 0.0, 1.0)
                        
                        if verbose:
                            log(f"Set {specular_input.name} to {specular_input.default_value} on material: {material.name}", report_func=report_func)
                    
                    except Exception as e:
                        if verbose:
                            log(f"Warning: Could not set {specular_input.name} on material {material.name}: {e}", "WARNING", report_func=report_func)
            
            # Also handle other specular-related nodes
            elif node.type in ['BSDF_GLOSSY', 'BSDF_ANISOTROPIC']:
                # Remove or minimize glossy/anisotropic nodes that add specular reflection
                if verbose:
                    log(f"Found specular node type {node.type} in material {material.name} - marking for removal", report_func=report_func)
                nodes_to_remove.append(node)
        
        # Remove the marked links first
        for link in links_to_remove:
            try:
                material.node_tree.links.remove(link)
            except:
                pass  # Link might already be removed
        
        # Remove the marked nodes
        for node in nodes_to_remove:
            try:
                material.node_tree.nodes.remove(node)
            except:
                pass  # Node might already be removed
            
    except Exception as e:
        log(f"Warning: Error cleaning material properties for '{material.name}': {e}", "WARNING", report_func)

def apply_texture_compression(image, target_format, jpeg_quality=85, force_compression=True, verbose=True, report_func=None):
    """Apply texture compression by setting format and compressing via file save/reload."""
    try:
        if not image:
            return
        
        original_format = image.file_format
        was_packed = image.packed_file is not None
        
        if target_format == 'JPEG':
            if verbose:
                log(f"Converting '{image.name}' to JPEG format (quality: {jpeg_quality}%)", report_func=report_func)
            
            # Set JPEG format
            image.file_format = 'JPEG'
            
            # Set quality for export
            try:
                image.file_format_quality = jpeg_quality / 100.0
            except AttributeError:
                # Fallback for older Blender versions
                bpy.context.scene.render.image_settings.quality = jpeg_quality
            
            # Force compression by saving and reloading if needed
            if force_compression or original_format != 'JPEG':
                try:
                    import tempfile
                    import os
                    
                    # Save to temporary file with compression
                    temp_dir = tempfile.gettempdir()
                    temp_file = os.path.join(temp_dir, f"temp_{image.name}.jpg")
                    
                    # Set render settings for JPEG quality (used by image.save_render)
                    original_quality = bpy.context.scene.render.image_settings.quality
                    original_format = bpy.context.scene.render.image_settings.file_format
                    
                    bpy.context.scene.render.image_settings.file_format = 'JPEG'
                    bpy.context.scene.render.image_settings.quality = jpeg_quality
                    
                    # Save with JPEG compression using render settings
                    image.filepath_raw = temp_file
                    image.save_render(temp_file)
                    
                    # Restore original render settings
                    bpy.context.scene.render.image_settings.quality = original_quality
                    bpy.context.scene.render.image_settings.file_format = original_format
                    
                    # Reload the compressed version
                    image.filepath = temp_file
                    image.source = 'FILE'
                    image.reload()
                    
                    # Pack if it was originally packed
                    if was_packed:
                        image.pack()
                    
                    # Clean up temp file
                    try:
                        os.remove(temp_file)
                    except:
                        pass
                    
                    if verbose:
                        log(f"Successfully compressed '{image.name}' to JPEG with quality {jpeg_quality}%", report_func=report_func)
                        
                except Exception as e:
                    if verbose:
                        log(f"Warning: Could not save/reload compress '{image.name}': {e}", report_func=report_func)
                    # Just set format without compression
                        
        elif target_format == 'PNG':
            image.file_format = 'PNG'
            if verbose:
                log(f"Keeping '{image.name}' as PNG format", report_func=report_func)
        
        # Update the image
        image.update()
        
    except Exception as e:
        log(f"Warning: Error applying compression to '{image.name}': {e}", "WARNING", report_func)

def process_material_textures(material, config, report_func=None):
    """Process all textures in a material."""
    if not material.use_nodes:
        return 0
    
    # Extract config values
    target_resolution = config.get('TARGET_RESOLUTION', 512)
    texture_format = config.get('TEXTURE_FORMAT', 'AUTO')
    jpeg_quality = config.get('JPEG_QUALITY', 85)
    remove_specular = config.get('REMOVE_SPECULAR', True)
    aggressive_jpeg = config.get('AGGRESSIVE_JPEG_CONVERSION', True)
    verbose = config.get('VERBOSE', True)
    
    # First clean up material properties (remove specular tint, set specular to 0)
    clean_material_properties(material, remove_specular, verbose, report_func)
    
    processed_count = 0
    
    for node in material.node_tree.nodes:
        if node.type == 'TEX_IMAGE' and node.image:
            image = node.image
            
            # Skip if image is already processed
            if hasattr(image, '_bulk_processed'):
                continue
            
            # Skip specular tint images that should have been removed
            image_name_lower = image.name.lower()
            node_name_lower = node.name.lower()
            if any(keyword in image_name_lower for keyword in ['specular_tint', 'spectint', 'spec_tint', 'specular tint']) or \
               any(keyword in node_name_lower for keyword in ['specular_tint', 'spectint', 'spec_tint', 'specular tint']):
                if verbose:
                    log(f"Skipping specular tint texture that should have been removed: {image.name}", report_func=report_func)
                continue
                
            original_packed = image.packed_file is not None
            
            # Determine optimal format based on actual image content
            target_format = get_texture_format(image.name, image, texture_format, aggressive_jpeg)
            
            # Apply texture compression format
            apply_texture_compression(image, target_format, jpeg_quality, config.get('FORCE_COMPRESSION', True), verbose, report_func)
            
            # Count this as processed since we applied compression
            processed_count += 1
            
            # Resize if needed
            if image.size[0] > target_resolution or image.size[1] > target_resolution:
                if verbose:
                    log(f"Resizing '{image.name}' from {image.size[0]}x{image.size[1]} to {target_resolution}x{target_resolution}", report_func=report_func)
                
                # Resize the image in memory
                image.scale(target_resolution, target_resolution)
                image.update()
                
                if verbose:
                    log(f"Successfully resized texture '{image.name}'", report_func=report_func)
            else:
                if verbose:
                    log(f"Image '{image.name}' already at or below target resolution ({image.size[0]}x{image.size[1]})", report_func=report_func)
            
            # If it was originally packed, keep it packed (embedded in GLB)
            if original_packed and not image.packed_file:
                try:
                    image.pack()
                    if verbose:
                        log(f"Re-packed texture '{image.name}' for embedding", report_func=report_func)
                except Exception as e:
                    log(f"Warning: Could not re-pack texture '{image.name}': {e}", "WARNING", report_func)
            
            # Mark as processed
            image['_bulk_processed'] = True
    
    return processed_count

def process_single_file(input_path, output_path, config, report_func=None):
    """Process a single 3D file (GLB/GLTF/VRM)."""
    try:
        log(f"Processing: {input_path.name}", report_func=report_func)
        
        # Clear the scene
        clear_scene(config['VERBOSE'], report_func)
        
        # Import the file based on its type
        if not import_file(input_path, config['VERBOSE'], report_func):
            return False
        
        # First clean up all materials (remove specular tint, set specular to 0)
        if config.get('REMOVE_SPECULAR', True):
            for material in bpy.data.materials:
                if material.users > 0:  # Only process materials that are actually used
                    clean_material_properties(material, True, config['VERBOSE'], report_func)
        
        # Process materials and textures
        total_textures_processed = 0
        processed_materials = 0
        
        for material in bpy.data.materials:
            if material.users > 0:  # Only process materials that are actually used
                texture_count = process_material_textures(material, config, report_func)
                if texture_count > 0:
                    processed_materials += 1
                    total_textures_processed += texture_count
        
        log(f"Processed {total_textures_processed} textures across {processed_materials} materials", report_func=report_func)
        
        # Export the processed file (output_path already has correct extension)
        input_file_type = get_file_type(input_path)
        
        if input_file_type == 'vrm':
            success = export_file(output_path, 'vrm', config['VERBOSE'], report_func)
        elif config['PRESERVE_FORMAT'] and input_file_type == 'gltf' and output_path.suffix.lower() == '.gltf':
            # Export as GLTF to maintain compatibility
            success = export_file(output_path, 'gltf', config['VERBOSE'], report_func)
        else:
            # Export as GLB
            success = export_file(output_path, 'glb', config['VERBOSE'], report_func)
        
        if success:
            log(f"Successfully exported: {output_path.name}", report_func=report_func)
            return True
        else:
            return False
            
    except Exception as e:
        log(f"Error processing file '{input_path}': {e}", "ERROR", report_func)
        traceback.print_exc()
        return False

def get_file_size_mb(filepath):
    """Get file size in megabytes."""
    try:
        return os.path.getsize(filepath) / (1024 * 1024)
    except:
        return 0

def run_optimization(config, report_func=None):
    """Main optimization function that processes all files in the input directory."""
    try:
        log("Starting GLTF/GLB/VRM Bulk Optimizer", report_func=report_func)
        log(f"Input directory: {config['INPUT_DIR']}", report_func=report_func)
        log(f"Output directory: {config['OUTPUT_DIR']}", report_func=report_func)
        log(f"Target resolution: {config['TARGET_RESOLUTION']}x{config['TARGET_RESOLUTION']}", report_func=report_func)
        log(f"Texture format: {config['TEXTURE_FORMAT']}", report_func=report_func)
        if config.get('REMOVE_SPECULAR'):
            log("Specular removal: ENABLED", report_func=report_func)
        if config.get('AGGRESSIVE_JPEG_CONVERSION'):
            log("Aggressive JPEG conversion: ENABLED", report_func=report_func)
        if config['TEXTURE_FORMAT'] in ['AUTO', 'JPEG']:
            log(f"JPEG quality: {config['JPEG_QUALITY']}%", report_func=report_func)
        
        # Validate directories
        input_path = Path(config['INPUT_DIR'])
        output_path = Path(config['OUTPUT_DIR'])
        
        if not input_path.exists():
            log(f"Error: Input directory does not exist: {config['INPUT_DIR']}", "ERROR", report_func)
            return {'success': False, 'message': 'Input directory does not exist'}
        
        # Create output directory if it doesn't exist
        output_path.mkdir(parents=True, exist_ok=True)
        
        # Find all supported files
        supported_files = (list(input_path.glob("*.glb")) + list(input_path.glob("*.GLB")) + 
                          list(input_path.glob("*.gltf")) + list(input_path.glob("*.GLTF")) +
                          list(input_path.glob("*.vrm")) + list(input_path.glob("*.VRM")))
        
        if not supported_files:
            log("No .glb, .gltf, or .vrm files found in input directory", "WARNING", report_func)
            return {'success': False, 'message': 'No supported files found'}
        
        log(f"Found {len(supported_files)} files to process", report_func=report_func)
        
        # Process each file
        processed_count = 0
        skipped_count = 0
        error_count = 0
        total_size_before = 0
        total_size_after = 0
        
        for i, input_file in enumerate(supported_files, 1):
            log(f"\n--- Processing file {i}/{len(supported_files)} ---", report_func=report_func)
            
            # Determine output filename based on input type and settings
            input_type = get_file_type(input_file)
            if input_type == 'vrm':
                # VRM files always keep .vrm extension
                output_filename = input_file.stem + '.vrm'
            elif config['PRESERVE_FORMAT']:
                # Keep original format if preserve format is enabled
                output_filename = input_file.name
            else:
                # Convert GLTF to GLB for efficiency
                output_filename = input_file.stem + '.glb'
            
            output_file = output_path / output_filename
            
            # Skip if output file already exists and SKIP_EXISTING is True
            if config['SKIP_EXISTING'] and output_file.exists():
                log(f"Skipping existing file: {output_file.name}", report_func=report_func)
                skipped_count += 1
                continue
            
            # Record original file size
            original_size = get_file_size_mb(input_file)
            total_size_before += original_size
            
            # Process the file
            success = process_single_file(input_file, output_file, config, report_func)
            
            if success:
                processed_count += 1
                new_size = get_file_size_mb(output_file)
                total_size_after += new_size
                compression_ratio = ((original_size - new_size) / original_size * 100) if original_size > 0 else 0
                log(f"Size: {original_size:.2f}MB → {new_size:.2f}MB ({compression_ratio:+.1f}%)", report_func=report_func)
            else:
                error_count += 1
        
        # Final summary
        log(f"\n{'='*50}", report_func=report_func)
        log("PROCESSING COMPLETE", report_func=report_func)
        log(f"{'='*50}", report_func=report_func)
        log(f"Total files found: {len(supported_files)}", report_func=report_func)
        log(f"Successfully processed: {processed_count}", report_func=report_func)
        log(f"Skipped (already exist): {skipped_count}", report_func=report_func)
        log(f"Errors: {error_count}", report_func=report_func)
        
        if processed_count > 0:
            overall_compression = ((total_size_before - total_size_after) / total_size_before * 100) if total_size_before > 0 else 0
            log(f"Total size reduction: {total_size_before:.2f}MB → {total_size_after:.2f}MB ({overall_compression:+.1f}%)", report_func=report_func)
        
        return {
            'success': True,
            'processed': processed_count,
            'skipped': skipped_count,
            'errors': error_count,
            'total_files': len(supported_files)
        }
        
    except Exception as e:
        log(f"Critical error in optimization: {e}", "ERROR", report_func)
        traceback.print_exc()
        return {'success': False, 'message': str(e)} 