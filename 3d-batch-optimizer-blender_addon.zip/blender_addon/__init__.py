bl_info = {
    "name": "GLTF/GLB/VRM Bulk Optimizer",
    "author": "DOCTORdripp",
    "version": (1, 0, 0),
    "blender": (3, 0, 0),
    "location": "3D Viewport > Sidebar > Bulk Optimizer",
    "description": "Batch process and optimize GLTF, GLB, and VRM files with texture downscaling",
    "warning": "",
    "doc_url": "https://github.com/DOCTORdripp/blender-3d-batch-optimizer",
    "category": "Import-Export",
}

import bpy
import os
import sys
import traceback
from pathlib import Path
from mathutils import Vector
import tempfile
import shutil
from bpy.props import (
    StringProperty,
    IntProperty,
    BoolProperty,
    EnumProperty,
    PointerProperty
)
from bpy.types import (
    Panel,
    Operator,
    PropertyGroup,
    AddonPreferences
)

# Import our optimizer functions
from . import bulk_optimizer

class BulkOptimizerProperties(PropertyGroup):
    """Properties for the bulk optimizer addon"""
    
    input_dir: StringProperty(
        name="Input Directory",
        description="Directory containing GLTF, GLB, or VRM files to process",
        default="",
        subtype='DIR_PATH'
    )
    
    output_dir: StringProperty(
        name="Output Directory", 
        description="Directory where optimized files will be saved",
        default="",
        subtype='DIR_PATH'
    )
    
    target_resolution: IntProperty(
        name="Target Resolution",
        description="Target texture resolution (e.g., 512, 1024, 256)",
        default=512,
        min=64,
        max=4096
    )
    
    texture_format: EnumProperty(
        name="Texture Format",
        description="Texture compression format",
        items=[
            ('AUTO', 'Auto', 'Automatically choose optimal format'),
            ('JPEG', 'JPEG', 'Force all textures to JPEG'),
            ('PNG', 'PNG', 'Force all textures to PNG')
        ],
        default='AUTO'
    )
    
    jpeg_quality: IntProperty(
        name="JPEG Quality",
        description="JPEG compression quality (1-100)",
        default=85,
        min=1,
        max=100
    )
    
    preserve_format: BoolProperty(
        name="Preserve Format",
        description="Keep original file formats instead of converting to GLB",
        default=True
    )
    
    skip_existing: BoolProperty(
        name="Skip Existing",
        description="Skip processing if output file already exists",
        default=True
    )
    
    verbose: BoolProperty(
        name="Verbose Logging",
        description="Enable detailed progress logging",
        default=True
    )

class BULKOPT_OT_process_files(Operator):
    """Process all GLTF, GLB, and VRM files in the input directory"""
    bl_idname = "bulk_optimizer.process_files"
    bl_label = "Start Optimization"
    bl_description = "Begin batch processing of 3D files"
    bl_options = {'REGISTER'}
    
    def execute(self, context):
        props = context.scene.bulk_optimizer_props
        
        # Validate input directory
        if not props.input_dir or not os.path.exists(props.input_dir):
            self.report({'ERROR'}, "Please select a valid input directory")
            return {'CANCELLED'}
        
        # Validate output directory
        if not props.output_dir:
            self.report({'ERROR'}, "Please select an output directory")
            return {'CANCELLED'}
        
        # Create output directory if it doesn't exist
        os.makedirs(props.output_dir, exist_ok=True)
        
        try:
            # Set up configuration
            config = {
                'INPUT_DIR': props.input_dir,
                'OUTPUT_DIR': props.output_dir,
                'TARGET_RESOLUTION': props.target_resolution,
                'TEXTURE_FORMAT': props.texture_format,
                'JPEG_QUALITY': props.jpeg_quality,
                'PRESERVE_FORMAT': props.preserve_format,
                'SKIP_EXISTING': props.skip_existing,
                'VERBOSE': props.verbose
            }
            
            # Run the bulk optimization
            result = bulk_optimizer.run_optimization(config, self.report)
            
            if result['success']:
                self.report({'INFO'}, 
                    f"Processing complete! {result['processed']} files processed, "
                    f"{result['skipped']} skipped, {result['errors']} errors"
                )
            else:
                self.report({'ERROR'}, f"Processing failed: {result['message']}")
                return {'CANCELLED'}
                
        except Exception as e:
            self.report({'ERROR'}, f"Unexpected error: {str(e)}")
            return {'CANCELLED'}
        
        return {'FINISHED'}

class BULKOPT_OT_select_input_dir(Operator):
    """Select input directory"""
    bl_idname = "bulk_optimizer.select_input_dir"
    bl_label = "Select Input Directory"
    bl_description = "Choose the directory containing files to optimize"
    
    filepath: StringProperty(subtype="DIR_PATH")
    
    def execute(self, context):
        context.scene.bulk_optimizer_props.input_dir = self.filepath
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class BULKOPT_OT_select_output_dir(Operator):
    """Select output directory"""
    bl_idname = "bulk_optimizer.select_output_dir"
    bl_label = "Select Output Directory"
    bl_description = "Choose where to save optimized files"
    
    filepath: StringProperty(subtype="DIR_PATH")
    
    def execute(self, context):
        context.scene.bulk_optimizer_props.output_dir = self.filepath
        return {'FINISHED'}
    
    def invoke(self, context, event):
        context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}

class BULKOPT_PT_main_panel(Panel):
    """Main panel for bulk optimizer"""
    bl_label = "Bulk 3D Optimizer"
    bl_idname = "BULKOPT_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Bulk Optimizer"
    
    def draw(self, context):
        layout = self.layout
        props = context.scene.bulk_optimizer_props
        
        # Header
        layout.label(text="GLTF/GLB/VRM Bulk Optimizer", icon='PACKAGE')
        layout.separator()
        
        # Input/Output directories
        box = layout.box()
        box.label(text="Directories", icon='FOLDER_REDIRECT')
        
        row = box.row()
        row.prop(props, "input_dir", text="Input")
        row.operator("bulk_optimizer.select_input_dir", text="", icon='FOLDER_REDIRECT')
        
        row = box.row()
        row.prop(props, "output_dir", text="Output")
        row.operator("bulk_optimizer.select_output_dir", text="", icon='FOLDER_REDIRECT')
        
        # Settings
        box = layout.box()
        box.label(text="Optimization Settings", icon='SETTINGS')
        box.prop(props, "target_resolution")
        box.prop(props, "texture_format")
        
        if props.texture_format in ['AUTO', 'JPEG']:
            box.prop(props, "jpeg_quality")
        
        box.prop(props, "preserve_format")
        box.prop(props, "skip_existing")
        box.prop(props, "verbose")
        
        # Action buttons
        layout.separator()
        
        # Status check
        input_valid = props.input_dir and os.path.exists(props.input_dir)
        output_valid = bool(props.output_dir)
        
        if not input_valid:
            layout.label(text="⚠️ Select input directory", icon='ERROR')
        if not output_valid:
            layout.label(text="⚠️ Select output directory", icon='ERROR')
        
        # Main action button
        row = layout.row()
        row.scale_y = 1.5
        row.enabled = input_valid and output_valid
        row.operator("bulk_optimizer.process_files", icon='PLAY')
        
        # Info
        layout.separator()
        box = layout.box()
        box.label(text="Supported Formats:", icon='INFO')
        col = box.column(align=True)
        col.label(text="• GLB files (binary)")
        col.label(text="• GLTF files (text-based)")
        col.label(text="• VRM files (avatars)")
        
        # Attribution
        layout.separator()
        col = layout.column(align=True)
        col.scale_y = 0.8
        row = col.row(align=True)
        row.alignment = 'CENTER'
        row.label(text="Built with love")
        row = col.row(align=True)
        row.alignment = 'CENTER'
        row.label(text="by DOCTORdripp")

# Registration
classes = [
    BulkOptimizerProperties,
    BULKOPT_OT_process_files,
    BULKOPT_OT_select_input_dir,
    BULKOPT_OT_select_output_dir,
    BULKOPT_PT_main_panel,
]

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    
    bpy.types.Scene.bulk_optimizer_props = PointerProperty(type=BulkOptimizerProperties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    
    del bpy.types.Scene.bulk_optimizer_props

if __name__ == "__main__":
    register() 