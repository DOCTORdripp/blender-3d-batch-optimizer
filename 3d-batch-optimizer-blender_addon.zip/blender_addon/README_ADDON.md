# 🎯 GLTF/GLB/VRM Bulk Optimizer - Blender Addon

A user-friendly Blender addon that provides a graphical interface for batch processing and optimizing 3D files directly within Blender.

## ✨ Features

- **🖼️ Graphical Interface** - Easy-to-use panel in Blender's sidebar
- **📁 Directory Browser** - Point-and-click folder selection
- **⚡ Real-time Feedback** - Progress updates and error reporting in Blender UI
- **🎛️ Visual Controls** - All settings accessible through intuitive interface
- **🔄 All File Formats** - GLB, GLTF, and VRM support with format preservation options

## 🛠️ Installation

### Method 1: Install from ZIP (Recommended)

1. **Download** the `blender_addon` folder and compress it to a ZIP file
2. **Open Blender** → Edit → Preferences → Add-ons
3. **Click "Install..."** button
4. **Select** the ZIP file containing the addon
5. **Enable** the addon by checking the box next to "GLTF/GLB/VRM Bulk Optimizer"

### Method 2: Manual Installation

1. **Locate** your Blender addons directory:
   - **Windows**: `%APPDATA%\Blender Foundation\Blender\[version]\scripts\addons\`
   - **macOS**: `~/Library/Application Support/Blender/[version]/scripts/addons/`
   - **Linux**: `~/.config/blender/[version]/scripts/addons/`

2. **Copy** the entire `blender_addon` folder to the addons directory
3. **Rename** it to `bulk_optimizer` (remove `blender_addon` prefix)
4. **Restart Blender**
5. **Enable** the addon in Preferences → Add-ons

## 🚀 Usage

### Accessing the Addon

1. **Open Blender**
2. **In the 3D Viewport**, press `N` to open the sidebar
3. **Look for** the "Bulk Optimizer" tab
4. **Click** to expand the panel

### Using the Interface

#### 📁 **Step 1: Set Directories**
- **Input Directory**: Click the folder icon to select your source folder containing GLB/GLTF/VRM files
- **Output Directory**: Click the folder icon to select where optimized files should be saved

#### ⚙️ **Step 2: Configure Settings**
- **Target Resolution**: Set desired texture resolution (512, 1024, etc.)
- **Texture Format**: Choose AUTO, JPEG, or PNG compression
- **JPEG Quality**: Adjust compression quality (1-100)
- **Preserve Format**: Keep original file formats vs convert to GLB
- **Skip Existing**: Automatically skip files already in output directory
- **Verbose Logging**: Enable detailed progress messages

#### ▶️ **Step 3: Start Processing**
- **Verify** both directories are selected (warning icons will disappear)
- **Click** "Start Optimization" button
- **Monitor** progress in Blender's info area and system console

### 📊 Real-time Feedback

The addon provides feedback through multiple channels:

- **✅ Status Messages** in Blender's info area (top bar)
- **📝 Detailed Logs** in system console (Window → Toggle System Console)
- **⚠️ Visual Warnings** for missing directories or settings
- **📈 Progress Updates** showing file counts and compression ratios

## 🎛️ Settings Reference

| Setting | Description | Default |
|---------|-------------|---------|
| **Target Resolution** | Maximum texture size (64-4096) | 512 |
| **Texture Format** | Compression method | AUTO |
| **JPEG Quality** | Compression quality for JPEG | 85 |
| **Preserve Format** | Keep original vs convert to GLB | True |
| **Skip Existing** | Skip files already processed | True |
| **Verbose Logging** | Detailed progress messages | True |

## 🔧 Requirements

- **Blender 3.0+** with Python API
- **VRM Addon** (optional, only for .vrm files) - [Download here](https://vrm-addon-for-blender.info/en/)

## 📋 Troubleshooting

### Common Issues

**❌ "Addon not appearing in sidebar"**
- Check that addon is enabled in Preferences → Add-ons
- Try restarting Blender
- Verify addon folder structure is correct

**❌ "No files found" error**
- Ensure input directory contains .glb, .gltf, or .vrm files
- Check file extensions are correct (case-sensitive on some systems)

**❌ "VRM import failed"**
- Install VRM addon from official source
- Ensure VRM addon is enabled in Preferences

**❌ "Processing stops unexpectedly"**
- Check system console for detailed error messages
- Try processing with smaller batch sizes
- Verify sufficient disk space in output directory

### Getting Help

- **📝 Check Console**: Window → Toggle System Console for detailed logs
- **🔍 Verify Settings**: Ensure all directories and options are set correctly
- **🔄 Restart Blender**: Sometimes resolves addon conflicts

## 🆚 Addon vs Command Line

| Feature | Addon | Command Line |
|---------|-------|--------------|
| **Ease of Use** | ✅ Point & click | ❌ Technical setup |
| **Visual Feedback** | ✅ Real-time UI | ❌ Console only |
| **Batch Size** | ⚠️ Memory limited | ✅ Unlimited |
| **Integration** | ✅ Native Blender | ❌ External tool |
| **Automation** | ❌ Manual operation | ✅ Scriptable |

## 📄 License

Licensed under the Apache License, Version 2.0. See main project LICENSE file for details.

---

<div align="center">
<strong>🎉 Enjoy bulk optimizing your 3D files with ease!</strong>
</div> 